gcd(A,B,Result) :- A =< 0, Result = B.
gcd(A,B,Result) :- B =< 0, Result = A. 
gcd(A,B,Result) :- A > 0, B > 0, A>=B, NewA is A-B, gcd(NewA,B,Result).
gcd(A,B,Result) :- A > 0, B > 0, A<B, NewB is B-A, gcd(A,NewB,Result).

query(gcd(5,10,Result)).




