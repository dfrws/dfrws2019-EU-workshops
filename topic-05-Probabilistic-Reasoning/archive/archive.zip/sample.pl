% Probability of door sensor being on or off
0.9::door(door,on,8);
0.1::door(door,off,9).

% probability of window sensor being on or off
0.5::window(window,on,10);
0.5::window(window,off,11).

% probability of fire sensor being on or off
0.5::fire(fire,on,8);
0.5::fire(fire,off,9).

% probability of the alarm system choosing to examine specific sensors in specific order
1/6::choice(door,window,D,DS,DL,W,WS,WL,F,FS,FL);
1/6::choice(window,door,D,DS,DL,W,WS,WL,F,FS,FL);
1/6::choice(door,fire,D,DS,DL,W,WS,WL,F,FS,FL);
1/6::choice(fire,door,D,DS,DL,W,WS,WL,F,FS,FL);
1/6::choice(window,fire,D,DS,DL,W,WS,WL,F,FS,FL);
1/6::choice(fire,window,D,DS,DL,W,WS,WL,F,FS,FL) :- door(D,DS,DL),window(W,WS,WL),fire(F,FS,FL).

% This predicate attaches values to S1S, S1L, S2S, and S2L 
% based on the sensors chosen by the alarm system (S1, S2).
msg(S1,S1S,S1L,S2,S2S,S2L) :- choice(S1,S2,S1,S1S,S1L,S2,S2S,S2L,_,_,_);
                      choice(S1,S2,S2,S2S,S2L,S1,S1S,S1L,_,_,_);
                      choice(S1,S2,S1,S1S,S1L,_,_,_,S2,S2S,S2L);
                      choice(S1,S2,S2,S2S,S2L,_,_,_,S1,S1S,S1L);
                      choice(S1,S2,_,_,_,S1,S1S,S1L,S2,S2S,S2L);
                      choice(S1,S2,_,_,_,S2,S2S,S2L,S1,S1S,S1L).

% Calculate length of the message
length_of_msg(L) :- msg(S1,S1S,S1L,S2,S2S,S2L),L is S1L+S2L.

% Assuming that the observed message length was 17 bytes
evidence(length_of_msg(17),true).

% what is the posterior probability distribution of different possible messages 
% with that size?
query(msg(S1,S1S,S1L,S2,S2S,S2L)).


