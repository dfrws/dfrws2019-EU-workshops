gcd(A,B,Result) :- A =< 0, Result = B.
gcd(A,B,Result) :- B =< 0, Result = A. 
gcd(A,B,Result) :- A > 0, B > 0, A>=B, NewA is A-B, gcd(NewA,B,Result).
gcd(A,B,Result) :- A > 0, B > 0, A<B, NewB is B-A, gcd(A,NewB,Result).

% Probability distribution of A: 1<=A<=10
0.1::a(1);
0.1::a(2);
0.1::a(3);
0.1::a(4);
0.1::a(5);
0.1::a(6);
0.1::a(7);
0.1::a(8);
0.1::a(9);
0.1::a(10).

% Probability distribution of B: 1<=B<=10
0.1::b(1);
0.1::b(2);
0.1::b(3);
0.1::b(4);
0.1::b(5);
0.1::b(6);
0.1::b(7);
0.1::b(8);
0.1::b(9);
0.1::b(10).

model(A,B,Result) :- a(A),b(B),gcd(A,B,Result).

result(Result) :- model(_,_,Result).
inputs(A,B) :- model(A,B,_).

evidence(result(5)).
query(inputs(A,B)).